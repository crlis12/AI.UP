const mysql = require('mysql');

// 환경변수 또는 기본값 사용
const dbConfig = {
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || '2025_user',
  password: process.env.DB_PASSWORD || '8367569a!',
  database: process.env.DB_NAME || '2025_test'
};

// Azure 환경인 경우 SSL 설정 추가
if (process.env.DB_HOST && process.env.DB_HOST.includes('azure')) {
  dbConfig.ssl = {
    rejectUnauthorized: false
  };
}

console.log('데이터베이스 연결 설정:', {
  host: dbConfig.host,
  user: dbConfig.user,
  database: dbConfig.database
});

const connection = mysql.createConnection(dbConfig);

// 데이터베이스 연결
connection.connect((err) => {
  if (err) {
    console.error('MySQL 연결 실패:', err);
    return;
  }
  console.log(`MySQL 연결 성공! (${dbConfig.host})`);
});

module.exports = connection;
